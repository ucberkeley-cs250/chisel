#ifndef __TEST_MACROS_H
#define __TEST_MACROS_H

#include "test_riscv.h"
#include "test_macros_scalar.h"

#endif // __TEST_MACROS_H
