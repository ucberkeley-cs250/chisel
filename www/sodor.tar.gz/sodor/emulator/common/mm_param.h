const int mem_clock_divide = 1;
const int mem_latency = 10;
const int refill_size = 4; // # of cycles to refill one cache line
const int LG_MM_WORD_SIZE = 4;
const int MM_WORD_SIZE = 1 << LG_MM_WORD_SIZE;
